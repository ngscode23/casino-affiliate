// src/lib/analytics.ts
import posthog from "posthog-js";

let inited = false;


// src/lib/analytics.ts

// ... твои импорты и остальной код

let _analyticsEnabled = false;

/** Включение аналитики (по согласию пользователя через CookieBar) */
export function enableAnalytics() {
  if (_analyticsEnabled) return; // не инициализируем повторно
  _analyticsEnabled = true;

  try {
    // Если у тебя PostHog
    if (import.meta.env.VITE_POSTHOG_KEY) {
      // можно прямо тут включить capture_pageview = true, если отключал
      console.info("[analytics] Analytics enabled");
    }

    // Если используешь GA через gtag — проверим
    if (typeof window !== "undefined" && typeof window.gtag === "function") {
      window.gtag("consent", "update", { analytics_storage: "granted" });
    }
  } catch (e) {
    if (import.meta.env.DEV) console.warn("[enableAnalytics] error:", e);
  }
}



///
export function initAnalytics() {
  if (inited) return;

  const key = import.meta.env.VITE_POSTHOG_KEY as string | undefined;
  if (!key) {
    if (import.meta.env.DEV) console.warn("[analytics] VITE_POSTHOG_KEY not set");
    return;
  }

  const host = (import.meta.env.VITE_POSTHOG_HOST as string | undefined) || "https://app.posthog.com";

  posthog.init(key, {
    api_host: host,
    autocapture: true,
    capture_pageview: false,
    persistence: "localStorage",
  });

  inited = true;
}

export function track(
  nameOrPayload: string | TrackPayload,
  params?: Record<string, unknown>
) {
  try {
    const name =
      typeof nameOrPayload === "string" ? nameOrPayload : nameOrPayload?.name;
    const payload =
      typeof nameOrPayload === "string" ? params ?? {} : nameOrPayload?.params ?? {};

    if (!name) return;

    // GA (если включён)
    if (typeof window !== "undefined" && typeof (window as any).gtag === "function") {
      (window as any).gtag("event", name, payload);
    }

    // PostHog (если подключён)
    try {
      // импорт сверху у тебя уже есть: import posthog from "posthog-js";
      // не падаем, если PostHog не инициализирован
   
      posthog?.capture?.(name, payload);
    } catch {}
  } catch (e) {
    if (import.meta.env.DEV) console.warn("[analytics.track] error:", e);
  }
}

export function trackPageview(path?: string) {
  if (!inited) initAnalytics();
  try {
    posthog.capture("$pageview", { path: path ?? location.pathname });
  } catch (e) {
    if (import.meta.env.DEV) console.warn("[analytics.pageview] error:", e);
  }
}

// GA helpers (минимум для совместимости)
export const GA_ID: string = (import.meta.env.VITE_GA_ID as string) ?? "";

export type ConsentState = { analytics: boolean; marketing: boolean };

const A_ATTR = "data-analytics-consent";
const M_ATTR = "data-marketing-consent";
const EVENT_NAME = "cookie-consent-changed";

export function getConsent(): ConsentState {
  try {
    const a = document.documentElement.getAttribute(A_ATTR);
    const m = document.documentElement.getAttribute(M_ATTR);
    return { analytics: a === "granted", marketing: m === "granted" };
  } catch {
    return { analytics: false, marketing: false };
  }
}

export function setConsent(analytics: boolean, marketing: boolean) {
  try {
    document.documentElement.setAttribute(A_ATTR, analytics ? "granted" : "denied");
    document.documentElement.setAttribute(M_ATTR, marketing ? "granted" : "denied");
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { analytics, marketing } }));
  } catch (e) {
    if (import.meta.env.DEV) console.warn("[analytics.setConsent] error:", e);
  }
}

let _gaReady = false;
export function setGaReady(v: boolean) {
  _gaReady = v;
}
export function isGaReady() {
  return _gaReady;
}
export function onConsentChanged(): void {
  // no-op placeholder
}

// src/lib/analytics.ts

export type TrackPayload = {
  name: string;
  params?: Record<string, unknown>;
};

/** Универсальная отправка событий:
 *  - track("event_name", { ... })
 *  - track({ name: "event_name", params: { ... } })
 */
